ucsd_ros_project
================

This repository contains all ROS packages and source code created by the MURO lab

http://muro.ucsd.edu/

Some potentially useful links:

http://u.cs.biu.ac.il/~yehoshr1/89-689/
